<div class="justify-content-center table-responsive">
    <table style="border: 1px solid black;" class="table table-bordered">
        <thead>
            <tr>
                <th class="text-left align-top table-success" width="250px">No Pesanan</th>
                <td><span id="nopesanan"></span></td>
                <th class="text-left align-top table-success" width="250px">Nama Pesanan</th>
                <td width="350px">Spanduk</td>
            </tr>
            <tr>
                <th class="text-left align-top table-success">Pelanggan</th>
                <td>123456789</td>
                <th class="text-left align-top table-success">No. Handphone</th>
                <td>Spanduk</td>
            </tr>
            <tr>
                <th class="text-left align-top table-success">Alamat</th>
                <td colspan="3">123456789</td>

            </tr>
            <tr>
                <th class="text-left align-top table-success">Tanggal Pesan</th>
                <td>123456789</td>
                <th class="text-left align-top table-success">Tangga Ambil</th>
                <td>Spanduk</td>
            </tr>
            <tr>
                <th height="80px" class="text-left align-top table-success">Uraian Pesanan</th>
                <td colspan="3">123456789</td>
            </tr>
            <tr>
                <th height="80px" class="text-left align-top table-success">Keterangan</th>
                <td colspan="3">123456789</td>
            </tr>
        </thead>

        <tbody>


        </tbody>

    </table>
    <br>
    <table style="border: 1px solid black;" class="table table-bordered responsive">
        <thead>
            <tr>
                <th rowspan="2" class="text-center align-middle table-warning">Qty</th>
                <th colspan="2" class="text-center align-middle table-warning">Dimensi</th>
                <th rowspan="2" class="text-center align-middle table-warning">@Harga</th>
                <th rowspan="2" class="text-center align-middle table-warning">Jasa Desain</th>
                <th rowspan="2" class="text-center align-middle table-warning">Biaya Lain</th>
                <th rowspan="2" class="text-center align-middle table-warning">Total</th>
            </tr>
            <tr>
                <th class="text-center align-middle table-warning">Panjang</th>
                <th class="text-center align-middle table-warning">Lebar</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="text-center align-middle">Dimensi</td>
                <td class="text-center align-middle">Dimensi</td>
                <td class="text-center align-middle">Dimensi</td>
                <td class="text-center align-middle">Dimensi</td>
                <td class="text-center align-middle">Dimensi</td>
                <td class="text-center align-middle">Dimensi</td>
                <td class="text-center align-middle">Dimensi</td>
            </tr>
        </tbody>
        <thead>
            <tr>
                <th colspan="6" class="text-center align-middle table-warning">Uang Muka</th>
                <td></td>
            </tr>
            <tr>
                <th colspan="6" class="text-center align-middle table-danger">Sisa</th>
                <td></td>
            </tr>
        </thead>
    </table>
</div>