<!-- Dashboard js -->
<script src="<?= base_url('assets/'); ?>js\vendors\jquery-3.2.1.min.js"></script>
<script src="<?= base_url('assets/'); ?>js\vendors\bootstrap.bundle.min.js"></script>
<script src="<?= base_url('assets/'); ?>js\vendors\jquery.sparkline.min.js"></script>
<script src="<?= base_url('assets/'); ?>js\vendors\selectize.min.js"></script>
<script src="<?= base_url('assets/'); ?>js\vendors\jquery.tablesorter.min.js"></script>
<script src="<?= base_url('assets/'); ?>js\vendors\circle-progress.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins\rating\jquery.rating-stars.js"></script>

<!-- Fullside-menu Js-->
<script src="<?= base_url('assets/'); ?>plugins\fullside-menu\jquery.slimscroll.min.js"></script>
<script src="<?= base_url('assets/'); ?>plugins\fullside-menu\waves.min.js"></script>

<!-- Custom scroll bar Js-->
<script src="<?= base_url('assets/'); ?>plugins\scroll-bar\jquery.mCustomScrollbar.concat.min.js"></script>

<!-- Custom Js-->
<script src="<?= base_url('assets/'); ?>js\custom.js"></script>
</body>

</html>